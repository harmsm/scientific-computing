__description__ = \
"""
my_module

A module holding handy functions for doing math.
"""
__author__ = "Michael J. Harms (harmsm@gmail.com)"
__date__ = "2020-04-01"

# I can import modules I need here
import math


def multiply_ab(a,b=5):
    """
    Multiply two numbers

    a: a number
    b: a number (default: 5)

    returns a*b
    """

    return a*b


def divide_sqrt_ab(a,b=5):
    """
    Divide two numbers and take their square root.

    a: a number
    b: a number (default: 5)

    returns a/b
    """

    return math.sqrt(a/b)
