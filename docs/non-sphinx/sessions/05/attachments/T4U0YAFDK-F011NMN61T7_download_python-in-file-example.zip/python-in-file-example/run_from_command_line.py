## To run this, type `python run_from_command_line.py` in your terminal

import my_module

print(my_module.multiply_ab(5,5))
print(my_module.divide_sqrt_ab(100,10))
